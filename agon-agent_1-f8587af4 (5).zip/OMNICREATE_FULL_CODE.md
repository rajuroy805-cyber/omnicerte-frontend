# OmniCreate.ai - Full Stack Setup Guide

This document contains the complete code for both the Frontend (React) and Backend (Node.js) of OmniCreate.ai.

---

## 1. BACKEND SETUP (Node.js)

1. Create a new folder named `server`
2. Run these commands inside the `server` folder:
   ```bash
   npm init -y
   npm install express multer cors axios cloudinary form-data @elevenlabs/elevenlabs-js replicate
   ```
3. Open `package.json` in the `server` folder and add `"type": "module"` below `"main": "index.js"`.
4. Create a file named `server.js` and paste the following code:

### `server/server.js`

```javascript
import express from "express";
import multer from "multer";
import cors from "cors";
import axios from "axios";
import { v2 as cloudinary } from "cloudinary";
import fs from "fs";
import FormData from "form-data";
import { ElevenLabsClient } from "@elevenlabs/elevenlabs-js";
import Replicate from "replicate";

// ==========================================
// CONFIGURATION (REPLACE WITH YOUR REAL KEYS)
// ==========================================
cloudinary.config({
  cloud_name: "YOUR_CLOUDINARY_NAME",
  api_key: "YOUR_CLOUDINARY_KEY",
  api_secret: "YOUR_CLOUDINARY_SECRET"
});

const RUNWAY_API_KEY = "YOUR_RUNWAY_API_KEY"; 
const ELEVENLABS_API_KEY = "sk_d4f88450b6d0ad8ee138bc77ec61a1f499bf7dcc2cce6bc5";
const REPLICATE_API_TOKEN = "key_a4c9474a470c72eae1961f47d9443b85692ae69bbe8e0c1eae7ad67b0f14caf3c2d42182c6b5318e386881fac258f489138dfbaec002cd4cdd248758d7a4e689";

const elevenlabs = new ElevenLabsClient({ apiKey: ELEVENLABS_API_KEY });
const replicate = new Replicate({ auth: REPLICATE_API_TOKEN });

const app = express();
app.use(cors());
app.use(express.json());

const upload = multer({ dest: "uploads/" });

// ==========================================
// 1. IMAGE TO VIDEO API (RunwayML + Cloudinary)
// ==========================================
app.post("/generate", upload.single("image"), async (req, res) => {
  try {
    const imagePath = req.file.path;

    // STEP 1: Upload image to cloudinary
    const img = await cloudinary.uploader.upload(imagePath);

    // STEP 2: AI video generate (Runway API)
    const aiVideo = await axios.post(
      "https://api.runwayml.com/v1/video/generate",
      {
        input: {
          image: img.secure_url,
          prompt: "cinematic motion, realistic"
        }
      },
      {
        headers: {
          Authorization: \`Bearer \${RUNWAY_API_KEY}\`
        }
      }
    );

    const generatedVideoUrl = aiVideo.data.output.video_url;

    // STEP 3: Upload generated video to cloudinary for permanent storage
    const finalVideo = await cloudinary.uploader.upload(generatedVideoUrl, {
      resource_type: "video"
    });
    
    const finalSecureUrl = finalVideo.secure_url;

    // Cleanup local uploaded image
    if (fs.existsSync(imagePath)) fs.unlinkSync(imagePath);
    
    // STEP 4: Return URL to Frontend
    res.json({ videoUrl: finalSecureUrl });

  } catch (err) {
    console.error("Image to Video error:", err);
    res.status(500).send("Error generating video");
  }
});

// ==========================================
// 2. VIDEO DUBBING API (ElevenLabs + Replicate Wav2Lip)
// ==========================================
app.post("/dubbing", upload.single("video"), async (req, res) => {
  try {
    const videoPath = req.file.path;
    const targetLanguage = req.body.targetLanguage;

    // STEP 1: Upload original video to Cloudinary
    const videoUploadResult = await cloudinary.uploader.upload(videoPath, { resource_type: "video" });
    const publicOriginalVideoUrl = videoUploadResult.secure_url;

    // STEP 2: AI DUBBING API (ElevenLabs Voice Translation)
    const fileStream = fs.createReadStream(videoPath);
    const dubbingResponse = await elevenlabs.dubbing.dub_a_video_or_an_audio_file({
      file: fileStream,
      target_lang: "hi", // e.g., 'hi' for Hindi
      source_lang: "auto",
      num_speakers: 1
    });
    
    const dubbingId = dubbingResponse.dubbing_id;
    // NOTE: In production, you must poll this endpoint until status is 'succeeded'
    const dubbedAudioUrl = \`https://api.elevenlabs.io/v1/dubbing/\${dubbingId}/audio/hi\`;

    // STEP 3: LIP SYNC (Wav2Lip on Replicate)
    const syncOutput = await replicate.run(
      "devxpy/wav2lip:8d65e3f4f4298520e079198b493c25adfc43c058ffec924f2aefc8010ed25eef",
      {
        input: {
          face: publicOriginalVideoUrl, // Original video URL
          audio: dubbedAudioUrl,        // New Hindi audio URL
          pads: "0 10 0 0",
          smooth: true,
          fps: 25
        }
      }
    );
    
    const finalDubbedVideoUrl = syncOutput;
    
    // STEP 4: Save final synced video to Cloudinary
    const finalResult = await cloudinary.uploader.upload(finalDubbedVideoUrl, { resource_type: "video" });
    const finalUrl = finalResult.secure_url;

    // Cleanup local uploaded video
    if (fs.existsSync(videoPath)) fs.unlinkSync(videoPath);
    
    res.json({ videoUrl: finalUrl });

  } catch (err) {
    console.error("Dubbing error:", err);
    res.status(500).send("Error dubbing video");
  }
});

app.listen(3000, () => console.log("Server running on port 3000"));
```

---

## 2. FRONTEND SETUP (React + Vite + Tailwind)

1. Create a Vite React project:
   ```bash
   npm create vite@latest frontend -- --template react-ts
   cd frontend
   npm install
   npm install framer-motion react-router-dom lucide-react clsx tailwind-merge
   ```
2. Setup Tailwind CSS (follow official Tailwind Vite guide).
3. Update `src/App.tsx` and `src/pages/Dashboard.tsx` with the code below.

### `src/App.tsx`

```tsx
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Landing from './pages/Landing';
import Dashboard from './pages/Dashboard';
import Login from './pages/Login';
import { useState, useEffect } from 'react';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    const auth = localStorage.getItem('omnicreate_auth');
    if (auth) {
      setIsAuthenticated(true);
    }
  }, []);

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Login setIsAuthenticated={setIsAuthenticated} />} />
        <Route 
          path="/dashboard" 
          element={ isAuthenticated ? <Dashboard /> : <Navigate to="/login" replace /> } 
        />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
```

### `src/pages/Dashboard.tsx` (Key API Integration Part)

```tsx
// This is the function that calls your Node.js backend
const handleGenerateRealVideo = async () => {
  if (!imageInputRef.current?.files?.[0]) {
    alert("Please upload an image first!");
    return;
  }

  setStatus1('loading');

  try {
    const file = imageInputRef.current.files[0];
    const formData = new FormData();
    formData.append("image", file);

    // Call the backend running on port 3000
    const res = await fetch("http://localhost:3000/generate", {
      method: "POST",
      body: formData
    });

    if (!res.ok) throw new Error("Server error");
    
    const data = await res.json();
    
    // Set the video URL returned from Cloudinary
    setGeneratedVideoUrl(data.videoUrl);
    setStatus1('done');

  } catch (error) {
    console.error("Backend Error:", error);
    alert("Make sure your Node.js backend is running on port 3000!");
    setStatus1('idle');
  }
};
```

---

## How to Run Locally

1. Open Terminal 1:
   ```bash
   cd server
   node server.js
   ```
   *(Ensure you have replaced the YOUR_API_KEY placeholders in server.js)*

2. Open Terminal 2:
   ```bash
   cd frontend
   npm run dev
   ```

3. Open `http://localhost:5173` in your browser. Upload an image, click Generate, and watch the real magic happen!
