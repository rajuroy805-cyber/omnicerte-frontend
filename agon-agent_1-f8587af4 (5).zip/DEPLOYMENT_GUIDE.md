# OmniCreate.ai - Complete Deployment Guide (Local to Live)

Yeh ek step-by-step guide hai jisse aap apne **OmniCreate.ai** project ko apne computer se lekar puri duniya ke liye live (Vercel aur Render/Heroku par) kar sakte hain. Is guide me hum Frontend aur Backend dono ko alag-alag host karenge.

---

## STEP 1: Code ko Apne Computer me Save Karein
Sabse pehle aapko is poore project ka code apne computer me download karna hoga. Is project me 2 hisse hain:
1. **Frontend:** (React/Vite) jo user dekhta hai.
2. **Backend:** (`server/` folder) jo AI APIs se baat karta hai.

---

## STEP 2: GitHub par Upload Karein (Source Code Management)

1. **GitHub Account:** [github.com](https://github.com) par apna account banayein.
2. **New Repository:** Ek naya repository (folder) banayein jiska naam rakhein `omnicreate-frontend`.
3. **Upload Frontend:** Apne computer se Frontend ka saara code (bina `server/` folder aur bina `node_modules` ke) is repository me upload kar dein.
4. **Second Repository:** Ek aur naya repository banayein jiska naam rakhein `omnicreate-backend`.
5. **Upload Backend:** Apne computer se sirf `server/` folder ke andar ka code is dusre repository me upload kar dein.

*(Note: Aap GitHub Desktop app ka use karke aasaani se code upload kar sakte hain).*

---

## STEP 3: Frontend ko Vercel par Live Karein (Free)

Vercel frontend (React) websites ko host karne ke liye sabse best aur free platform hai.

1. **Vercel Account:** [vercel.com](https://vercel.com) par jayen aur GitHub se login karein.
2. **Add New Project:** "Add New" -> "Project" par click karein.
3. **Import from GitHub:** Vercel aapse puchega ki kis repository ko live karna hai. Wahan se `omnicreate-frontend` ko select (Import) karein.
4. **Deploy:** Vercel khud samajh jayega ki ye React app hai. Bas "Deploy" button par click karein.
5. **Live URL:** 2 minute me Vercel aapko ek link dega (jaise `omnicreate.vercel.app`). Ye aapki website ka live link hai!

---

## STEP 4: Backend ko Live Karein (Render.com par)

Vercel par backend (Node.js/Express jo lagatar chalta hai) host karna theek nahi hota. Backend ke liye hum **Render.com** (ya Heroku) ka use karenge.

1. **Render Account:** [render.com](https://render.com) par jayen aur GitHub se login karein.
2. **New Web Service:** "New" -> "Web Service" par click karein.
3. **Connect GitHub:** Apna `omnicreate-backend` wala repository select karein.
4. **Settings:**
   - Name: `omnicreate-api`
   - Environment: `Node`
   - Build Command: `npm install`
   - Start Command: `node server.js`
5. **Environment Variables (Secret Keys):** "Advanced" me jakar apne secret passwords dalein taaki code me kisi ko na dikhein:
   - `ELEVENLABS_API_KEY` = `sk_d4f8...`
   - `REPLICATE_API_TOKEN` = `key_a4c9...`
   - `CLOUDINARY_URL` = (Apna cloudinary link)
6. **Deploy:** "Create Web Service" par click karein.
7. **Live API URL:** Render aapko ek link dega (jaise `https://omnicreate-api.onrender.com`). Ye aapka live backend hai!

---

## STEP 5: Frontend aur Backend ko Jodein (Connect)

Ab aapka Frontend Vercel par hai aur Backend Render par. In dono ko aapas me jodne ki zaroorat hai.

1. Apne computer me Frontend ka code kholein (VS Code me).
2. `src/pages/Dashboard.tsx` file kholein.
3. Jahan-jahan `http://localhost:3000` ya `https://your-backend-url` likha hai, usko apne naye Render API link se badal dein.
   *Example:*
   ```javascript
   // Pehle:
   const res = await fetch("http://localhost:3000/generate", {...})
   
   // Baad me:
   const res = await fetch("https://omnicreate-api.onrender.com/generate", {...})
   ```
4. Code save karein aur wapas GitHub par upload (Push) kar dein.
5. Vercel khud-b-khud naya code fetch karke website update kar dega.

---

## STEP 6: Asli AI API Code Chalu Karein (Final Step)

Abhi backend (`server.js`) me asli AI call karne wala code comments (`/* ... */`) ke andar chupa hua hai (taaki bina API key ke error na aaye).

Jab aapka sab kuch live ho jaye aur aapke paas API keys hon:
1. `server.js` file kholein.
2. Jo code `/*` aur `*/` ke beech me hai, uske aas-paas se `/*` aur `*/` hata dein (Uncomment karein).
3. Jo Mock response (dummy video) wala code hai, usko delete kar dein.
4. Naya code GitHub par push karein. Render automatically backend update kar dega.

---

## Badhai Ho! 🎉
Ab aapka OmniCreate.ai poori duniya ke liye live hai. Log aapki website par jayenge, photo upload karenge, photo Render server par jayegi, wahan se Replicate (AI) ke paas jayegi, video banegi, Cloudinary me save hogi, aur wapas user ko dikhegi!